"""Náhrada za validation_results.py bez Djanga.

Pôvodný modul si pri importe ťahá Django a SQLite kvôli zápisu výsledkov do
databázy validačnej služby. V prehliadači sa výsledky nikam neukladajú —
odovzdávajú sa rovno do rozhrania — takže stačia čisté dataclassy.
"""
from ifc_validation_models.dataclass_compat import (
    ValidationOutcome, OutcomeSeverity, ValidationOutcomeCode,
)

ValidationOutcomeDjango = None
ModelInstance = None
ValidationTask = None
